# ReadPdf
android阅读pdf文档
<h2><b>效果展示:</b></h2>
<br/>
<img src= "https://github.com/zhoukai1526/ReadPdf/blob/master/app/src/main/row/pdf.gif"/>
<br/>
<h2><b>说明:</b></h2>
<ul>
<li>由于测试pdf较大文件在第一次加载的时候会很慢，可能需要1-2分钟，请耐心等待</li>
<li>阅读pdf是使用js来请求的和解析的，可能会因为跨域的问题而请求失败</li>
</ul>
