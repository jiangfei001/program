package com.mcxiaoke.bus.test;

/**
 * User: mcxiaoke
 * Date: 15/7/31
 * Time: 16:21
 */
public class BusTest {
}
